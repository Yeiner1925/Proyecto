# Nombre de estudiantes

# Yeiner jair anchico quiñonez-2366745-2724 
# Jossua David rojas Obando - 2466976-2724
# Luis manuel hurtado alomia- 2466770-2724

import tkinter as tk
import random

# Datos del jugador (saldo, apuestas ganadas y perdidas)
#se crea un diccionario con los datos del jugador, saldo, apuestas ganadas y perdidas
jugador = {
    "saldo": 100,
    "apuestas": [],
    "ganadas": 0,
    "perdidas": 0
}

# Configuración de la ruleta
rojos = {1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36}
negros = set(range(1, 37)) - rojos
secciones = {
    "primera": set(range(1, 13)),
    "segunda": set(range(13, 25)),
    "tercera": set(range(25, 37))
}

# Función para girar la ruleta
def girar_ruleta():
    #escoge aleatoriamente con la funcion randint que devuelve un entero que se encuentra en el intervalo que se le dio
    resultado = random.randint(0, 36)
    #verifica el color si es verde es el 0 si no evaluara entre rojo y negro y procedera entrar al for
    color = "verde" if resultado == 0 else ("rojo" if resultado in rojos else "negro")
    
    # Evaluar apuestas
    total_ganado = 0
    for apuesta in jugador["apuestas"]:
        tipo, valor, monto = apuesta
        if (tipo == "numero" and resultado == valor) or \
           (tipo == "color" and color == valor) or \
           (tipo == "seccion" and resultado in secciones.get(valor, {})) or \
           (tipo == "rango" and ((valor == "1to18" and 1 <= resultado <= 18) or (valor == "19to36" and 19 <= resultado <= 36))):
            if tipo == "numero":
                total_ganado += monto * 20
            elif tipo == "color":
                total_ganado += monto * 2
            elif tipo == "seccion":
                total_ganado += monto * 5
            elif tipo == "rango":
                total_ganado += monto * 2
            jugador["ganadas"] += 1
        else:
            jugador["perdidas"] += 1
    
    jugador["saldo"] += total_ganado
    jugador["apuestas"] = []
    actualizar_info(resultado, color, total_ganado)
# Función para realizar una apuesta
def apostar(tipo, valor, monto):
    if jugador["saldo"] >= monto:
        jugador["saldo"] -= monto
        jugador["apuestas"].append((tipo, valor, monto))
        actualizar_info()
    else:
        info_label.config(text="Saldo insuficiente")

# Función para actualizar la interfaz
def actualizar_info(resultado=None, color=None, total_ganado=0):
    saldo_label.config(text=f"Saldo: {jugador['saldo']}")
    ganadas_label.config(text=f"Ganadas: {jugador['ganadas']}")
    perdidas_label.config(text=f"Perdidas: {jugador['perdidas']}")
    total_apostado = sum(apuesta[2] for apuesta in jugador["apuestas"])
    apuestas_label.config(text=f"Apostado: {total_apostado}")
    promedio_exito = jugador["ganadas"] / jugador["perdidas"] if jugador["perdidas"] > 0 else jugador["ganadas"]
    exito_label.config(text=f"Promedio de éxito: {promedio_exito:.2f}")
    if resultado is not None:
        info_label.config(text=f"Resultado: {resultado} ({color}) - Ganado: {total_ganado}")

# Crear interfaz gráfica
root = tk.Tk()
root.title("Ruleta de Apuestas")
#se muestra en pantalla la info del jugador 
saldo_label = tk.Label(root, text=f"Saldo: {jugador['saldo']}", font=("Arial", 14))
saldo_label.pack()

ganadas_label = tk.Label(root, text=f"Ganadas: {jugador['ganadas']}", font=("Arial", 14))
ganadas_label.pack()

perdidas_label = tk.Label(root, text=f"Perdidas: {jugador['perdidas']}" , font=("Arial", 14))
perdidas_label.pack()

apuestas_label = tk.Label(root, text=f"Apostado: 0", font=("Arial", 14))
apuestas_label.pack()

exito_label = tk.Label(root, text=f"Promedio de éxito: 0.00", font=("Arial", 14))
exito_label.pack()

# Crear el tablero de la ruleta
tablero_frame = tk.Frame(root)
tablero_frame.pack()

numeros = [
    [0],
    [3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36],
    [2, 5, 8, 11, 14, 17, 20, 23, 26, 29, 32, 35],
    [1, 4, 7, 10, 13, 16, 19, 22, 25, 28, 31, 34]
]
# organizacion de los numeros del tablero
for fila_idx, fila in enumerate(numeros):
    for col_idx, num in enumerate(fila):
        color = "red" if num in rojos else "black" if num in negros else "green"
        btn = tk.Button(tablero_frame, text=str(num), width=5, height=2, bg=color, fg="white",
                        command=lambda n=num: apostar("numero", n, 10))
        btn.grid(row=fila_idx, column=col_idx)

# Crear botones de apuesta de forma organizada
botones_frame = tk.Frame(root)
botones_frame.pack()

tk.Button(botones_frame, text="1 to 18", width=10, command=lambda: apostar("rango", "1to18", 10)).grid(row=0, column=0)
tk.Button(botones_frame, text="EVEN", width=10, command=lambda: apostar("paridad", "par", 10)).grid(row=0, column=1)
tk.Button(botones_frame, text="RED", width=10, bg="red", fg="white", command=lambda: apostar("color", "rojo", 10)).grid(row=0, column=2)
tk.Button(botones_frame, text="BLACK", width=10, bg="black", fg="white", command=lambda: apostar("color", "negro", 10)).grid(row=0, column=3)
tk.Button(botones_frame, text="ODD", width=10, command=lambda: apostar("paridad", "impar", 10)).grid(row=0, column=4)
tk.Button(botones_frame, text="19 to 36", width=10, command=lambda: apostar("rango", "19to36", 10)).grid(row=0, column=5)

tk.Button(root, text="Girar Ruleta", command=girar_ruleta , font=("Arial", 16)).pack(pady=10)

info_label = tk.Label( root, text="Realiza tu apuesta y gira la ruleta",  font=("Arial", 16), pady=10)
info_label.pack()

root.mainloop()
